#include<iostream>
using namespace std;

class Time{
    int hours;
    int minutes;
    int seconds;
    public:
        void setHour(int h){
            hours=h;
        }
        void setMinute(int m){
            minutes=m;
        }
        void setSecond(int s){
            seconds=s;
        }
        void setTime(int h=0,int m=0,int s=0){
            hours=h;
            minutes=m;
            seconds=s;
        }

        int getHour(){
            return hours;
        }
        int getMinute(){
            return minutes;
        }
        int getSecond(){
            return seconds;
        }

        void printTwentyFourHourFormat(){
            cout<<"Time(24 Hour Format)"<<endl<<hours<<" : "<<minutes<<" : "<<seconds<<endl;
        }

        void printTwelveHourFormat(){
            int h=hours/12;
            cout<<"Time(12 hour format)"<<endl;
            if(hours==0){
                cout<<"12 : "<<minutes<<" : "<<seconds<<" AM"<<endl;
            }
            else if(hours==12){
                cout<<"12 : "<<minutes<<" : "<<seconds<<" PM"<<endl;
            }
            else if(h==0){
                cout<<hours<<" : "<<minutes<<" : "<<seconds<<" AM"<<endl;
            }
            else{
                cout<<hours-12<<" : "<<minutes<<" : "<<seconds<<" PM"<<endl;
            }
        }
        
        void incHour(int h=0){
            int temp=hours;
            temp+=h;
            if(temp>=24){
                hours=temp%24;   //reseting the day
            }else{
                hours=temp;
            }
        }

        void incMin(int m=0){
            int temp=minutes;
            temp+=m;
            if(temp>=60){
                int extraHour=temp/60;   //Find added Hours
                incHour(extraHour);
                minutes=temp%60;     //storing added minutes
            }
            else{
                minutes=temp;
            }
        }

        void incSec(int s=0){
            int temp=seconds;
            temp+=s;
            if(temp>=60){
                int extraMin=temp/60;  //Find added min
                incMin(extraMin);
                seconds=temp%60;   //storing added seconds
            }else{
                seconds=temp;
            }
        }
        
};

void displayMenu() {
    cout << "Select an option:" << endl;
    cout << "1. Set Hour" << endl;
    cout << "2. Set Minute" << endl;
    cout << "3. Set Second" << endl;
    cout << "4. Set Time (Hour, Minute, Second)" << endl;
    cout << "5. Print Time (24-hour format)" << endl;
    cout << "6. Print Time (12-hour format)" << endl;
    cout << "7. Increment Seconds" << endl;
    cout << "8. Increment Minutes" << endl;
    cout << "9. Increment Hours" << endl;
    cout << "10. Get Hours" << endl;
    cout << "11. Get Minutes" << endl;
    cout << "12. Get Seconds" << endl;
    cout << "Others to. Exit" << endl;
}

int main(){
    Time x;
    int count=0;
    while(true){
    if(count==0){
    displayMenu();
    count=1;
    }
    int choice;
    cout<<"Enter Choice: "<<endl;
    cin>>choice;
    
    if(choice==1){
    while(true){
        int h;
        cout<<"Enter the hour(24-hour Format i.e 0 to 23)"<<endl;
        cin>>h;
        if(h>=0 && h<24){
            x.setHour(h);
            break;
        }
        else{
            cout<<"Wrong Hour! Try Again"<<endl;
        }
    }
    }
    
    else if(choice==2){
    while(true){
        int h;
        cout<<"Enter the minute(0 to 59)"<<endl;
        cin>>h;
        if(h>=0 && h<60){
            x.setMinute(h);
            break;
        }
        else{
            cout<<"Wrong Minute! Try Again"<<endl;
        }
    }
    }
    else if(choice==3){
    while(true){
        int h;
        cout<<"Enter the second(0 to 59)"<<endl;
        cin>>h;
        if(h>=0 && h<60){
            x.setSecond(h);
            break;
        }
        else{
            cout<<"Wrong Minute! Try Again"<<endl;
        }
    }
    }

    else if(choice==4){
        while(true){
        int h;
        cout<<"Enter the hours(0 to 23)"<<endl;
        cin>>h;
        int m;
        cout<<"Enter the minute(0 to 59)"<<endl;
        cin>>m;
        int s;
        cout<<"Enter the second(0 to 59)"<<endl;
        cin>>s;
        if((h>=0 && h<24) && (m>=0 && m<60) && (s>=0 && s<60)){
            x.setTime(h,m,s);
            break;
        }
        else{
            cout<<"SomeThing is not correct!!"<<endl<<"Try Again"<<endl;
        }
        }
    }

    else if(choice==5){
        x.printTwentyFourHourFormat();
    }

    else if(choice==6){
        x.printTwelveHourFormat();
    }
    else if(choice==7){
        while(true){
        int c;
        cout<<"Enter added seconds(>0)";
        cin>>c;
        if(c>=0){
            x.incSec(c);
            break;
        }
        else{
            cout<<"Can't be Negative"<<endl<<"Try Again"<<endl;
        }
        }
    }
    else if(choice==8){
        while(true){
        int c;
        cout<<"Enter added minutes(>0)";
        cin>>c;
        if(c>=0){
            x.incMin(c);
            break;
        }
        else{
            cout<<"Can't be Negative"<<endl<<"Try Again"<<endl;
        }
        }

    }
    else if(choice==9){
        while(true){
        int c;
        cout<<"Enter added hours(>0)";
        cin>>c;
        if(c>=0){
            x.incHour(c);
            break;
        }
        else{
            cout<<"Can't be Negative"<<endl<<"Try Again"<<endl;
        }
        }

    }
    else if(choice==10){
            cout<<"Hour:  "<<x.getHour()<<endl;
    }
    else if(choice==11){
            cout<<"Minute:  "<<x.getMinute()<<endl;
    }
    else if(choice==12){
            cout<<"Seconds:  "<<x.getSecond()<<endl;
    }
    
    else{
        break;
    }
    cout<<endl<<endl;
    }
    return 0;
}